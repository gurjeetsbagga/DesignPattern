use Test;

Test::func_2_args(35, "bombay");

Test::func_with_keywords(25, "San Francisco");
