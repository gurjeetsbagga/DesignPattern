int 
draw_mandel (char *filename,
       	 int width, int height,
			 double origin_real,
		     double origin_imag,
		     double range,
		     double depth);
