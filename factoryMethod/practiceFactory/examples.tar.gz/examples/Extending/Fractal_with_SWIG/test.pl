use Fractal;
Fractal::draw_mandel('snowman.gif', 300, 300, -1.5, 1.0, 2.0, 20);

